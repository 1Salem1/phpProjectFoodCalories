import { Injectable } from '@angular/core';
import { listPlats } from '../../dataBase/listPlats';
import { PlatModel } from "../model/plat.model";

@Injectable({
  providedIn: 'root'
})
export class ListService {

  listPlat: PlatModel[] = listPlats;

  constructor() { }
}
