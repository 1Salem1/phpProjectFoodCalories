import { EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { PlatModel } from "../model/plat.model";

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  platSelectionnee$: EventEmitter<PlatModel> = new EventEmitter<PlatModel>();
  addOrderEventService: EventEmitter<PlatModel> = new EventEmitter<PlatModel>();

  constructor() { }
}
