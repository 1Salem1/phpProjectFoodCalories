export class PlatModel {
  id!: string;
  idPlat?: string;
  nomplat!: string;
  description!: string;
  note?: string;
  liste!: string[];
  listeRemoved?: string[];
  prix!: string;
  imageUrl!:string;
  cuisson!: boolean;
  cuissontype?: string;
  cuissontypeNb?: number;
  categorie!:number;
  quantitee?: number;
  prixInNumber?: number;
  selectionnee?: boolean;
  deleted?: boolean;
}
