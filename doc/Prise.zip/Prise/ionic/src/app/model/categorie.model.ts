export enum Catgorie {
  drinks,
  plat,
  pizza,
  viande,
  dessert
}
