import { Component, OnInit } from '@angular/core';
import { PlatModel } from "../../model/plat.model";
import { OrderService } from "../../Services/order.service";

@Component({
    selector: 'app-recap',
    templateUrl: './recap.component.html',
    styleUrls: ['./recap.component.scss']
})
export class RecapComponent implements OnInit {
    platSelectionnee?: PlatModel;
    listPlat: PlatModel[] = [];
    prixTotal = 0;

    constructor(private orderService: OrderService) { }

    ngOnInit(): void {
        this.orderService.addOrderEventService.subscribe((data: PlatModel) => {
            if (data) {
                if (data.deleted) {
                    this.supprimerPlat(data);
                }
                else {
                    let platExisteDeja = this.listPlat.find(plat => plat.id === data.id
                        && plat.cuissontype === data.cuissontype && plat.note === data.note
                        && plat.listeRemoved?.length == data.listeRemoved?.length);

                    if (platExisteDeja && this.isEquals(platExisteDeja, data) && platExisteDeja.quantitee && data.quantitee) {
                        platExisteDeja.quantitee += data.quantitee;
                        platExisteDeja.prixInNumber = parseInt(platExisteDeja.prix) * platExisteDeja.quantitee;
                    } else {
                        let newPlat = Object.assign({}, data);
                        this.listPlat.push(newPlat);
                    }
                    this.prixTotal += data.prixInNumber || 0;
                }
            }
        });
    }

    isEquals(plat1: PlatModel, plat2: PlatModel) {
        return plat1.listeRemoved?.every((value, index) => plat2.listeRemoved && value === plat2.listeRemoved[index]);
    }

    selectionnerPlat(plat: PlatModel) {
        let selected = plat.selectionnee;

        this.deSelectionnerPlat();

        plat.selectionnee = !selected;

        if (plat.selectionnee) {
            this.orderService.platSelectionnee$.emit(plat);
        }
        else {
            this.orderService.platSelectionnee$.emit(undefined);
        }
    }

    deSelectionnerPlat() {
        this.listPlat.forEach(plat => {
            plat.selectionnee = false;
        });
    }

    supprimerPlat(plat: PlatModel) {
        let index = this.listPlat.indexOf(plat);

        if (index > -1) {
            this.listPlat.splice(index, 1);
            this.prixTotal -= plat.prixInNumber || 0;
        }

        this.deSelectionnerPlat();
        this.orderService.platSelectionnee$.emit(undefined);
    }
}
