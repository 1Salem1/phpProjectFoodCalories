import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';

@Component({
  selector: 'app-nombre-plats',
  templateUrl: './nombre-plats.component.html',
  styleUrls: ['./nombre-plats.component.scss'],
})
export class NombrePlatsComponent implements OnInit {
  @Input() expert: boolean = false;
  @Input() openNumber: boolean = false;
  @Output() nombreChange = new EventEmitter<number>();
  @ViewChild('nb') inputElement!: any;

  constructor() { }

  ngOnInit(): void { }

  enterNumber(nb: any) {
    this.nombreChange.emit(nb);
  }

  openInput() {
    this.openNumber = !this.openNumber;
    setTimeout(() => {
      if (this.inputElement) {
          this.inputElement.setFocus();
      }
    }, 0);
  }
}
