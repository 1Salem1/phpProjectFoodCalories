import { DOCUMENT } from '@angular/common';
import { Component, ElementRef, Input, OnInit } from '@angular/core';
import { PlatModel } from "../../model/plat.model";
import { OrderService } from "../../Services/order.service";

@Component({
    selector: 'app-detail-plat',
    templateUrl: './detail-plat.component.html',
    styleUrls: ['./detail-plat.component.scss']
})
export class DetailPlatComponent implements OnInit {
    @Input() expert!: boolean;
    @Input() platSelected!: boolean;
    @Input() plat!: PlatModel;

    originalPlat!: PlatModel;
    closed: boolean = false;
    openNumber: boolean = false;
    platSelectionnee?: PlatModel = undefined;
    modify: boolean = false;

    constructor(private orderService: OrderService, private thisElement: ElementRef) {
        this.orderService.platSelectionnee$.subscribe((data: PlatModel) => {
            if (data) {
                this.platSelectionnee = data;

                if (this.platSelectionnee.selectionnee && this.platSelectionnee.id == this.plat.id) {
                    this.plat = this.platSelectionnee;
                    this.closed = true;

                    let bouton = this.thisElement.nativeElement.children[0].children[1].children[1].children[0];
                    bouton.focus();
                }
                else {
                    this.plat = this.originalPlat;
                    this.closed = false;
                }
            }
            else {
                this.platSelectionnee = undefined;
                this.plat = this.originalPlat;
                this.closed = false;
            }
        });
    }

    ngOnInit(): void {
        this.plat.listeRemoved = Object.assign([], this.plat.liste);
        this.plat.cuissontype = 'Bleu';
        this.plat.cuissontypeNb = 0;
        this.plat.note = "";
        this.plat.quantitee = 1;
        this.plat.prixInNumber = parseInt(this.plat.prix);
        this.originalPlat = this.plat;
        this.plat.deleted = false;
    }

    nbPlat($event: any) {
        this.plat.quantitee = $event;
        this.ajouterPrixTotal();
    }

    delete(plat: any) {
        plat.deleted = true;
        this.orderService.addOrderEventService.emit(plat);
    }

    removedIngrediens(ingredients: any, $event: any) {
        if (!$event.target.checked) {
            let index = this.plat.listeRemoved?.indexOf(ingredients);

            if (index != undefined && index > -1) {
                this.plat.listeRemoved?.splice(index, 1);
            }
        }
        else {
            let index = this.plat.listeRemoved?.indexOf(ingredients);
            if (index && index < 0) {
                this.plat.listeRemoved?.push(ingredients);
            }
        }
    }

    ajouterCuissonExpert(type: number) {
        if (this.plat.cuisson) {
            if (type == 0) {
                this.plat.cuissontype = 'Bleu';
                this.plat.cuissontypeNb = 0;
            }
            else if (type == 1) {
                this.plat.cuissontypeNb = 1;
                this.plat.cuissontype = 'Saignant';
            }
            else if (type == 2) {
                this.plat.cuissontypeNb = 2;
                this.plat.cuissontype = 'A point';
            }
            else {
                this.plat.cuissontypeNb = 3;
                this.plat.cuissontype = 'Bien cuit';
            }
        }
    }

    ajouterNote(event: any) {
        this.plat.note = event.target.value;
    }

    addToOrder(plat: PlatModel) {
        let newPlat = new PlatModel();

        newPlat.listeRemoved = Object.assign([], this.plat.listeRemoved);
        newPlat.cuissontype = this.plat.cuissontype;
        newPlat.cuissontypeNb = this.plat.cuissontypeNb;
        newPlat.note = this.plat.note;
        newPlat.quantitee = this.plat.quantitee;
        newPlat.prixInNumber = parseInt(this.plat.prix);
        newPlat.deleted = this.plat.deleted;
        newPlat.id = this.plat.id;
        newPlat.idPlat = this.generateIdUnique();
        newPlat.nomplat = this.plat.nomplat;
        newPlat.description = this.plat.description;
        newPlat.liste = Object.assign([], this.plat.liste);
        newPlat.prix = this.plat.prix;
        newPlat.imageUrl = this.plat.imageUrl;
        newPlat.cuisson = this.plat.cuisson;
        newPlat.categorie = this.plat.categorie;
        newPlat.selectionnee = this.plat.selectionnee;

        this.orderService.addOrderEventService.emit(newPlat);

        this.plat = Object.assign({}, this.originalPlat);
    }

    ajouterPrixTotal() {
        this.plat.prixInNumber = this.plat.quantitee ? parseInt(this.plat.prix) * this.plat.quantitee : parseInt(this.plat.prix);
    }

    generateIdUnique() {
        return 'xxx'.replace(/[xy]/g, (c) => {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    };
}
