import { IonicModule } from '@ionic/angular';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RechercheComponent } from './recherche/recherche.component';
import { DetailPlatComponent } from './detail-plat/detail-plat.component';
import { ListePlatsComponent } from './liste-plats/liste-plats.component';
import { NombrePlatsComponent } from './nombre-plats/nombre-plats.component';
import { CategoriesComponent } from './categories/categories.component';
import { RecapComponent } from './recap/recap.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';

@NgModule({
  imports: [
    IonicModule,
    CommonModule,
    FormsModule,
  ],
  declarations: [
    RechercheComponent,
    DetailPlatComponent,
    ListePlatsComponent,
    NombrePlatsComponent,
    CategoriesComponent,
    RecapComponent,
    HeaderComponent,
    FooterComponent,
  ],
  exports: [
    RechercheComponent,
    DetailPlatComponent,
    ListePlatsComponent,
    NombrePlatsComponent,
    CategoriesComponent,
    RecapComponent,
    HeaderComponent,
    FooterComponent,
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ComposantsPageModule {}
