import { DOCUMENT } from '@angular/common';
import { Component, DoCheck, ElementRef, Inject, Input, OnInit, ViewChild, ViewChildren, Renderer2, QueryList } from '@angular/core';
import { PlatModel } from "../../model/plat.model";
import { OrderService } from '../../Services/order.service';

@Component({
  selector: 'app-liste-plats',
  templateUrl: './liste-plats.component.html',
  styleUrls: ['./liste-plats.component.scss']
})
export class ListePlatsComponent implements OnInit, DoCheck {
  @Input() expert: boolean = false;
  @Input() listPlat: PlatModel[] = [];
  @ViewChildren('listPlats') listePlats!: QueryList<any>;

  platSelectionnee: boolean = false;
  idplatSelectionnee: string = "";

  lplat!: PlatModel[];
  mapPlats = new Map();

  constructor(private orderService: OrderService, @Inject(DOCUMENT) private document: Document) {
    this.lplat = this.listPlat;
    this.orderService.platSelectionnee$.subscribe((data: PlatModel) => {
      if (data) {
        this.platSelectionnee = true;
        this.idplatSelectionnee = data.id;
      }
      else {
        this.platSelectionnee = false;
      }
    });
  }

  ngOnInit() {
  }

  ngDoCheck(): void {
    if (this.platSelectionnee) {

    }
    this.lplat = this.listPlat;
  }
}
