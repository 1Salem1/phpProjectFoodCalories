export const listPlats = [
  {
    id: "s1",
    nomplat: "steak",
    description: "steak cuit à la flamme",
    liste: ["steak", "olive", "onion"],
    prix: '20€',
    cuisson: true,
    categorie: 3,
    imageUrl: "https://www.seriouseats.com/thmb/WzQz05gt5witRGeOYKTcTqfe1gs=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/butter-basted-pan-seared-steaks-recipe-hero-06-03b1131c58524be2bd6c9851a2fbdbc3.jpg"
  },
  {
      id: "c1",
      nomplat: "calzone",
      description: "pizza en forme de chausson",
      liste: ["pate", "olive", "fromage"],
      prix: '12€',
      cuisson: false,
      imageUrl: "https://www.chronodrive.com/le-studio/wp-content/uploads/2022/01/calzone-wordpress.jpg",
      categorie:2
    },
    {
      id: "c2",
      nomplat: "calzone poulet",
      description: "pizza en forme de chausson en poulet",
      liste: ["pate", "olive", "fromage", "poulet"],
      prix: '13€',
      cuisson: false,
      imageUrl: "https://www.chronodrive.com/le-studio/wp-content/uploads/2022/01/calzone-wordpress.jpg",
      categorie:2
    },
    {
      id: "c3",
      nomplat: "calzone Thon",
      description: "pizza en forme de chausson avec du thon",
      liste: ["pate", "olive", "fromage", "thon"],
      prix: '11€',
      cuisson: false,
      imageUrl: "https://www.chronodrive.com/le-studio/wp-content/uploads/2022/01/calzone-wordpress.jpg",
      categorie:2
    },
    {
      id: "n1",
      nomplat: "norvégienne",
      description: "pizza base planche",
      liste: ["pate", "saumon", "fromage"],
      prix: '16€',
      cuisson: false,
      imageUrl: "https://img.cuisineaz.com/660x660/2013/12/20/i5193-pizza-norvegienne.webp",
      categorie:3
    },
    {
      id: "c2",
      nomplat: "canibal",
      description: "pizza en forme de chausson",
      liste: ["pate", "olive", "anchois", "fromage"],
      prix:'15€',
      cuisson: false,
      imageUrl:"https://www.edenpizza.fr/wp-content/uploads/2019/11/edenpizza-cannibale.jpg",
      categorie:2
    },

    {
      id: "n2",
      nomplat:  "nicoise",
      description:"pizza en forme de chausson",
      liste: ["pate", "olive", "anchois"],
      prix:'12€',
      cuisson: false,
      imageUrl:"http://storage.canalblog.com/89/64/197541/51868900.jpg",
      categorie:2
    },
  {
  id: "4",
  nomplat:  "PANNA COTTA",
  description:"Panna cotta et coulis de fruits rouges",
  liste: ["mascarponne", "oeuf", "fruit rouge"],
  prix:'12€',
  cuisson: false,
  imageUrl:"http://storage.canalblog.com/89/64/197541/51868900.jpg",
  categorie:4
}
  ,
  {
    id: "4",
    nomplat:  "MOELLEUX AU CHOCOLAT",
    description:"Moelleux au chocolat maison et sans gluten, accompagné de sa boule de glace vanille et d'amandes",
    liste: ["oeuf", "chocolat", "glace"],
    prix:'12€',
    cuisson: false,
    imageUrl:"http://storage.canalblog.com/89/64/197541/51868900.jpg",
    categorie:4
  }

  ,
  {
    id: "4",
    nomplat:  "MOELLEUX AU CHOCOLAT",
    description:"Moelleux au chocolat maison et sans gluten, accompagné de sa boule de glace vanille et d'amandes",
    liste: ["oeuf", "chocolat", "glace"],
    prix:'12€',
    cuisson: false,
    imageUrl:"http://storage.canalblog.com/89/64/197541/51868900.jpg",
    categorie:4
  },
  {
    id: "4",
    nomplat:  "COCA-COLA",
    description:"",
    liste: [],
    prix:'3.9€',
    cuisson: false,
    imageUrl:"",
    categorie:1
  }
  ,
  {
    id: "4",
    nomplat:  "FANTA",
    description:"",
    liste: [],
    prix:'3.9€',
    cuisson: false,
    imageUrl:"",
    categorie:1
  },

  {
    id: "4",
    nomplat:  "SCHWEPPES lemon",
    description:"",
    liste: [],
    prix:'3.9€',
    cuisson: false,
    imageUrl:"",
    categorie:1
  },{
    id: "4",
    nomplat:  "SCHWEPPES Agrum",
    description:"",
    liste: [],
    prix:'3.9€',
    cuisson: false,
    imageUrl:"",
    categorie:1
  },
  {
    id: "4",
    nomplat:  "SEVEN-UP",
    description:"",
    liste: [],
    prix:'3.9€',
    cuisson: false,
    imageUrl:"",
    categorie:1
  },
  {
    id: "4",
    nomplat:  "SRITE",
    description:"",
    liste: [],
    prix:'3.9€',
    cuisson: false,
    imageUrl:"",
    categorie:1
  },
  {
    id: "2",
    nomplat: "poulet",
    description: "poulet grillé avec du citron et de l'ail",
    liste: ["poulet", "citron", "ail"],
    prix: '15€',
    cuisson: true,

    imageUrl:"",
    categorie: 3
     },
  {
    id: "1",
    nomplat: "Boeuf bourguignon",
    description: "Boeuf braisé lentement dans du vin rouge et des légumes",
    liste: ["boeuf", "vin rouge", "oignons", "carottes", "ail", "thym"],
    prix: '25€',
    cuisson: false,
    categorie: 3,
    imageUrl: ""
  },
  {
    id: "2",
    nomplat: "Lasagne Bolognaise",
    description: "Layers de pâtes à lasagne, viande hachée et béchamel",
    liste: ["pâtes à lasagne", "viande hachée", "tomate", "oignon", "ail", "farine", "lait", "beurre"],
    prix: '20€',
    cuisson: false,
    categorie: 3,
    imageUrl: ""
  },{
    id: "1",
    nomplat: "Entrecôte grillée",
    description: "Entrecôte grillée avec une marinade au poivre",
    liste: ["entrecôte", "poivre", "huile d'olive"],
    prix: '25€',
    cuisson: true,
    imageUrl: "",
    categorie: 3
  },{
    id: "2",
    nomplat: "Boeuf à la moutarde",
    description: "Boeuf mariné dans une sauce à la moutarde et aux herbes",
    liste: ["bœuf", "moutarde", "herbes"],
    prix: '20€',
    cuisson: true,
    imageUrl: "",
    categorie: 3
  }

    ];
