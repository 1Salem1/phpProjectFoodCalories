import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CategorieServiceService {
  public listCategorie: any[]=[]
  constructor() {

    this.listCategorie= ["Tout", "Apéritif", "Entré", "Plat", "Dessert"]
  }
}
