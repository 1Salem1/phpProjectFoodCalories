import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PlatModel } from '../../../model/plat.model';
import { ListService } from '../../../Services/list.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {
  expert: boolean = false;
  listPlatFiltree: PlatModel[];
  listPlat: PlatModel[];

  constructor(private route: ActivatedRoute, private platsService: ListService) {
    this.listPlat = this.platsService.listPlat;
    this.listPlatFiltree = this.platsService.listPlat;
  }

  ngOnInit(): void {
    let bool = this.route.snapshot.paramMap.get('expert');
    if (bool == "true") {
      this.expert = true;
    } else {
      this.expert = false;
    }
  }

  filtredData($event: any) {
    this.listPlatFiltree = $event;
    this.listPlat = this.platsService.listPlat;
  }


}
