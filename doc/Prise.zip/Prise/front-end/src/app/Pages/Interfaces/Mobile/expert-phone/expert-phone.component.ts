import { Component, OnInit } from '@angular/core';
import { PlatModel } from '../../../../model/plat.model';
import { ListService } from '../../../../Services/list.service';

@Component({
  selector: 'app-expert-phone',
  templateUrl: './expert-phone.component.html',
  styleUrls: ['./expert-phone.component.scss']
})
export class ExpertPhoneComponent implements OnInit {
  listPlatFiltree: PlatModel[];
  listPlat: PlatModel[];

  constructor(private platsService: ListService) {
    this.listPlat = this.platsService.listPlat;
    this.listPlatFiltree = this.platsService.listPlat;
  }

  ngOnInit(): void {
  }

  filtredData($event: any) {
    this.listPlatFiltree = $event;
    this.listPlat = this.platsService.listPlat;
  }
}
