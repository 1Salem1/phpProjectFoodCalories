import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PlatModel } from '../../../model/plat.model';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {
  @Input() listPlat: PlatModel[] = [];
  @Output() listeDesPlatsChange = new EventEmitter<PlatModel[]>();

  plat!: string;
  selectedCategory: any;
  listeDesPlats: PlatModel[] = [];
  listeDesPlatsFiltree: PlatModel[] = [];

  constructor() {
  }

  ngOnInit(){
    this.plat = "Plat principal";
    this.listeDesPlats = this.listPlat;
  }

  // gestionaire d'événement pour les boutons de catégorie
  onCategoryClick(event: any) {
    // récupération de  l'ID de la catégorie à partir de l'attribut de données du bouton
    const id = event.target.dataset.id;
    // sélectionner la catégorie en utilisant l'ID
    this.selectedCategory = this.filtrerListeDesPlats(id);
  }

  filtrerListeDesPlats = (id: number)=> {
    if (id === 0) {
      this.listeDesPlatsFiltree = this.listeDesPlats;
    }
    else {
      this.listeDesPlatsFiltree = this.listeDesPlats.filter((e: PlatModel) => e.categorie === id);
    }

    this.listeDesPlatsChange.emit(this.listeDesPlatsFiltree);
  }
}
