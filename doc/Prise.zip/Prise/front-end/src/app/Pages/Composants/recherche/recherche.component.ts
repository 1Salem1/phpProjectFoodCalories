import {Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import {PlatModel} from "../../../model/plat.model";

@Component({
  selector: 'app-recherche',
  templateUrl: './recherche.component.html',
  styleUrls: ['./recherche.component.scss']
})
export class RechercheComponent implements OnInit {

  @Input() listPlat: PlatModel[] = [];
  @Input() expert!: boolean;
  @Output() listPlatChange = new EventEmitter<PlatModel[]>();

  listPlatFiltree: PlatModel[] = [];

  constructor() { }

  ngOnInit(): void {
  }

  search($event: any) {
    if (this.expert) {
      this.listPlatFiltree = this.listPlat.filter((e: PlatModel) => e.id.includes($event));
    }
    else {
      this.listPlatFiltree = this.listPlat.filter((e: PlatModel) => e.nomplat.includes($event) || e.id.includes($event));
    }

    this.listPlatChange.emit(this.listPlatFiltree);
  }
}
