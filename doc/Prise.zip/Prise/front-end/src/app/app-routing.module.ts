import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent} from "./Pages/Interfaces/home/home.component";
import { ExpertPhoneComponent } from "./Pages/Interfaces/Mobile/expert-phone/expert-phone.component";
import { MainComponent } from './Pages/Interfaces/main/main.component';

// redirige selon ce que l'on veut
const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'Home', component: HomeComponent },
  { path: 'main/:expert', component: MainComponent },
  { path: 'phoneExpert', component: ExpertPhoneComponent },
  { path: '**', component: HomeComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
