import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { MatIconModule } from '@angular/material/icon'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './ComposantsFixes/header/header.component';
import { FooterComponent } from './ComposantsFixes/footer/footer.component';
import { RecapComponent } from './Pages/Composants/recap/recap.component';
import { ExpertPhoneComponent } from './Pages/Interfaces/Mobile/expert-phone/expert-phone.component';
import { CategoriesComponent } from './Pages/Composants/categories/categories.component';
import { HomeComponent } from './Pages/Interfaces/home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RechercheComponent } from './Pages/Composants/recherche/recherche.component';
import { DetailPlatComponent } from './Pages/Composants/detail-plat/detail-plat.component';
import { ListePlatsComponent } from "./Pages/Composants/liste-plats/liste-plats.component";
import { NombrePlatsComponent } from './Pages/Composants/nombre-plats/nombre-plats.component';
import { MainComponent } from './Pages/Interfaces/main/main.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    RecapComponent,
    ExpertPhoneComponent,
    CategoriesComponent,
    HomeComponent,
    RechercheComponent,
    DetailPlatComponent,
    ListePlatsComponent,
    NombrePlatsComponent,
    MainComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatIconModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
