export enum Catgorie {
  ALL,
  DRINKS,
  PIZZA,
  VIANDE,
  GATEAU
}
